#include "Clock.h"
#include <string>

WorldClock::WorldClock(int x)
{
change = x;
sum = 1;
	Clock::Clock();
}

std::string WorldClock::get_time()
{
	return Clock::get_time();

}
}

std::string Clock::get_hours()
{
int hours = Clock::get_hours();
	return hours+change;
}

std::string Clock::get_minutes()
{
	return Clock::get_minutes();
}
