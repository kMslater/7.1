#include "Clock.h"
#include <string>

Clock::Clock()
{
	current_time = time(0);
	local_time = localtime(&current_time);
	hours = local_time->tm_hour;
	minutes = local_time->tm_min;
}

std::string Clock::get_time()
{
	return get_hours() + " " + get_minutes();
}

std::string Clock::get_hours()
{
	std::string s = std::to_string(hours);
	return s;
}

std::string Clock::get_minutes()
{
	std::string s = std::to_string(minutes);
	return s;
}
