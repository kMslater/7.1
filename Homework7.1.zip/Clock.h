#pragma once
#define _CRT_SECURE_NO_WARNINGS


/**
Implement a class Clock whose get_hours and get_minutes member functions
return the current time at your location. To get the current time, use
the following code, which requires that you include the <ctime> header:

time_t current_time = time(0);
tm* local_time = localtime(&current_time);
int hours = local_time->tm_hour;
int minutes = local_time->tm_min;



Also provide a get_time member function that returns a string
with the hours and minutes by calling the get_hours and get_minutes
functions.

Make a Clock class with public functions:
string get_hours
string get_minutes

*/

/*
Provide a derived class WorldClock whose constructor
accepts a time offset. For example, if you live in California, a
new WorldClock(3)should show the time in New York, three time zones
ahead. Which member functions did you override? (You should not override
get_time.)*/

#include <time.h>
#include <ctime>
#include <string>



class Clock
{
	time_t current_time;
	tm* local_time;
	int hours;
	int minutes;

public:


	//ctor
	Clock();

	//calls get_hours() and get_minutes() 
	std::string get_time();

	//return string versions of time_t class datatype
	std::string get_hours();
	std::string get_minutes();
};

class WorldClock: public Clock{
int change = 0;
int sum = 0;

public:

WorldClock(int x);

std::string WorldClock::get_time();

Clock::get_hours();
Clock::get_minutes();
};
