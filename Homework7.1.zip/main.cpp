#include "Clock.h"

int main()
{
WorldClock clock = WorldClock(0);
cout<<"Local Time: " <<clock.get_time();

int temp;
cout << "Please enter the time shift number";
cin >> temp

	WorldClock clock = WorldClock(temp);
cout<<"Time Shift: " << clock.get_hours()<< " " << clock.get_minutes();


	return 0;
}